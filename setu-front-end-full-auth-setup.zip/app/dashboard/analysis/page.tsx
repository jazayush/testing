export default function AnalysisPage() {
  return (
    <div className="h-full bg-gray-50 flex items-center justify-center">
      <p className="text-gray-400 text-lg">Analysis Content</p>
    </div>
  )
}
