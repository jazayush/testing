export default function HistoryPage() {
  return (
    <div className="h-full bg-gray-50 flex items-center justify-center">
      <p className="text-gray-400 text-lg">Chat History Content</p>
    </div>
  )
}
