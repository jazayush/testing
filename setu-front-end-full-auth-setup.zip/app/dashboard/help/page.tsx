export default function HelpPage() {
  return (
    <div className="h-full w-full flex items-center justify-center bg-gray-50">
      <p className="text-gray-400 text-lg">Help Center Content</p>
    </div>
  )
}
